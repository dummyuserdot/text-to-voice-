import React, { useState } from "react";
import { Send, Volume2, Sparkles, User, Loader2, MessageSquare, Bot } from "lucide-react";
import { playGeminiTTS, stopAudio } from "../utils/audioService";

interface ChatMessage {
  id: string;
  sender: "user" | "character";
  character: "golu" | "ammi";
  text: string;
  timestamp: string;
}

const PRESET_QUESTIONS = [
  "Bhai Golu, bina kaam kiye ameer banne ka koi secret hack bata do? 😂",
  "Ammi, Golu jhaaru kyu lagaye jab usne billionaire banna hai? 🧹",
  "Client ne mera poster dekh kar kaha yeh bijli ka bill hai! Ab kya karoon? 💀",
  "Pehli freelancing kamai ₹5,000 Ammi ko dikhayi to unhone kya kiya? 💸",
];

export const AskCharacters: React.FC = () => {
  const [character, setCharacter] = useState<"golu" | "ammi">("golu");
  const [question, setQuestion] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "init-1",
      sender: "character",
      character: "golu",
      text: "Haan bhai! Main hoon Golu, the certified ₹5,000 graphic designer! Poocho kya poochna hai, bas Ammi ko mat batana ke main abhi bhi 11:30 baje uthta hoon! 🤣",
      timestamp: "Just now",
    },
  ]);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = customPrompt || question;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: "user",
      character,
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setQuestion("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/ask-character", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          character,
          question: textToSend,
        }),
      });

      const data = await response.json();
      const replyMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: "character",
        character,
        text: data.reply || "Bhai internet chala gaya, Ammi ne lagta hai router ka switch band kar diya! 😂",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, replyMsg]);
    } catch {
      const replyMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: "character",
        character,
        text: "Arrey bhai, network mein thoda jhatka lag gaya jaise Ammi ka jhaaru laga ho! Dobara try karo! 😂",
        timestamp: "Now",
      };
      setMessages((prev) => [...prev, replyMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeak = async (msg: ChatMessage) => {
    if (speakingId === msg.id) {
      stopAudio();
      setSpeakingId(null);
      return;
    }

    setSpeakingId(msg.id);
    await playGeminiTTS(
      {
        text: msg.text,
        voiceName: msg.character === "ammi" ? "Kore" : "Zephyr",
        speaker: msg.character === "ammi" ? "Ammi" : "Golu",
        style:
          msg.character === "ammi"
            ? "Sharp, hilarious desi mother giving quick reality check"
            : "Charming funny young freelancer bragging about his 5000 rupees",
      },
      () => setSpeakingId(msg.id),
      () => setSpeakingId(null),
      () => setSpeakingId(null)
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Intro & Character Toggle */}
      <div className="bg-stone-900 rounded-3xl p-5 sm:p-7 border border-stone-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-300 text-xs font-bold mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Interactive Character AI</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Ask Golu &amp; Ammi Anything!
            </h2>
            <p className="text-xs sm:text-sm text-stone-400">
              Get hilarious advice, desi reality checks, and freelancing tips directly from the characters.
            </p>
          </div>

          {/* Persona Switcher */}
          <div className="flex p-1 rounded-2xl bg-stone-850 border border-stone-750">
            <button
              onClick={() => setCharacter("golu")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                character === "golu"
                  ? "bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20"
                  : "text-stone-300 hover:text-white"
              }`}
            >
              <span>😎 Golu (Billionaire)</span>
            </button>
            <button
              onClick={() => setCharacter("ammi")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                character === "ammi"
                  ? "bg-rose-500 text-white shadow-md shadow-rose-500/20"
                  : "text-stone-300 hover:text-white"
              }`}
            >
              <span>🧹 Ammi (Jhaaru Specialist)</span>
            </button>
          </div>
        </div>

        {/* Preset Quick Chips */}
        <div className="flex flex-wrap gap-2 pt-2 border-t border-stone-800">
          <span className="text-xs text-stone-400 self-center font-semibold">Quick questions:</span>
          {PRESET_QUESTIONS.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(q)}
              className="text-xs px-3 py-1.5 rounded-xl bg-stone-800/80 hover:bg-stone-800 text-stone-300 hover:text-amber-300 border border-stone-700/60 transition-colors text-left"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="bg-stone-900 rounded-3xl border border-stone-800 p-4 sm:p-6 shadow-xl flex flex-col min-h-[380px] max-h-[500px]">
        <div className="flex-1 overflow-y-auto space-y-4 pr-1 scrollbar-thin">
          {messages.map((msg) => {
            const isUser = msg.sender === "user";
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}
              >
                {!isUser && (
                  <div
                    className={`w-9 h-9 rounded-2xl flex items-center justify-center text-lg flex-shrink-0 shadow-md ${
                      msg.character === "ammi"
                        ? "bg-rose-500/20 border border-rose-500/30 text-rose-300"
                        : "bg-amber-500/20 border border-amber-500/30 text-amber-300"
                    }`}
                  >
                    {msg.character === "ammi" ? "👵" : "😎"}
                  </div>
                )}

                <div
                  className={`max-w-[85%] sm:max-w-[75%] p-4 rounded-2xl space-y-1.5 shadow-md ${
                    isUser
                      ? "bg-amber-500 text-stone-950 rounded-br-none font-medium text-sm"
                      : "bg-stone-800/80 border border-stone-700 text-stone-100 rounded-bl-none text-sm"
                  }`}
                >
                  <div className="flex items-center justify-between gap-3 text-xs opacity-75">
                    <span className="font-bold">
                      {isUser ? "You" : msg.character === "ammi" ? "Ammi" : "Golu"}
                    </span>
                    <span>{msg.timestamp}</span>
                  </div>

                  <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>

                  {!isUser && (
                    <div className="pt-2 flex justify-end">
                      <button
                        onClick={() => handleSpeak(msg)}
                        className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1.5 font-bold px-2 py-1 rounded-lg hover:bg-stone-700/60 transition-colors"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>{speakingId === msg.id ? "Stop Voice" : "Listen (Gemini TTS)"}</span>
                      </button>
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-9 h-9 rounded-2xl bg-amber-500/20 border border-amber-500/30 text-amber-300 flex items-center justify-center flex-shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 justify-start items-center text-stone-400 text-xs">
              <div className="w-9 h-9 rounded-2xl bg-stone-800 flex items-center justify-center">
                <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
              </div>
              <span className="animate-pulse font-medium">
                {character === "ammi" ? "Ammi jhaaru rakh kar jawab soch rahi hain..." : "Golu billionaire formula likh raha hai..."}
              </span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="pt-4 mt-2 border-t border-stone-800 flex items-center gap-2">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
            placeholder={`Ask ${character === "ammi" ? "Ammi" : "Golu"} a question...`}
            className="flex-1 bg-stone-800/80 border border-stone-700 rounded-2xl px-4 py-3 text-sm text-white placeholder-stone-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={isLoading || !question.trim()}
            className="p-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 disabled:opacity-40 disabled:cursor-not-allowed text-stone-950 font-bold rounded-2xl shadow-lg transition-all"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
