import React, { useState } from "react";
import { Palette, Volume2, Sparkles, Loader2, AlertTriangle, Zap, Check } from "lucide-react";
import { playGeminiTTS, playSynthesizedSfx } from "../utils/audioService";

export const PosterMemeStudio: React.FC = () => {
  const [title, setTitle] = useState("COSMIC SAMOSA & CROREPATI SALE!");
  const [tagline, setTagline] = useState("DANCE! EAT! AMMI JHAARU IMMUNITY!");
  const [theme, setTheme] = useState<"disco" | "bill" | "neon" | "chaos">("disco");
  const [meterNo, setMeterNo] = useState("WAPDA-992-GOLU");
  const [unitsConsumed, setUnitsConsumed] = useState("420 Units");
  const [payableAmount, setPayableAmount] = useState("₹4,850");
  const [hasElectricWarning, setHasElectricWarning] = useState(true);

  const [isLoadingRoast, setIsLoadingRoast] = useState(false);
  const [clientRoast, setClientRoast] = useState<any>({
    roast: "Bhai, yeh poster kam aur 3 mahine purana bijli ka bill zyada lag raha hai! Pehle meter reading check karoon ya discount parhoon?! 😂",
    billScore: 98,
    ammiReaction: "Ammi: Iss bill ko dekh kar to sach mein bijli ka 440 volt jhatka lag gaya!",
  });

  const handleGenerateRoast = async () => {
    setIsLoadingRoast(true);
    playSynthesizedSfx("bill");

    try {
      const response = await fetch("/api/roast-poster", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          colors: theme,
          font: "Comic Sans Extra Bold",
          elements: `${hasElectricWarning ? "Electric warning" : ""}, Units: ${unitsConsumed}, Amount: ${payableAmount}`,
        }),
      });

      const data = await response.json();
      setClientRoast(data);
    } catch {
      setClientRoast({
        roast: "Client: Bhai yeh poster nahi hai, yeh to seedha Bijli Ghar ka notice hai! Meter cut hone wala hai! 😂",
        billScore: 95,
        ammiReaction: "Ammi: Dekha! Client ne bhi pehchan liya ke yeh bill hai!",
      });
    } finally {
      setIsLoadingRoast(false);
    }
  };

  const handleSpeakRoast = async () => {
    if (!clientRoast?.roast) return;
    await playGeminiTTS({
      text: `${clientRoast.roast} ${clientRoast.ammiReaction || ""}`,
      voiceName: "Charon",
      speaker: "Client",
      style: "Perplexed client looking with disbelief at a poster that looks like an electricity bill",
    });
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Intro Banner */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold uppercase tracking-wider">
          <Palette className="w-3.5 h-3.5" />
          <span>Meme Design Simulator</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white">
          ⚡ &quot;Poster Hai Ya Bijli Ka Bill?&quot; Lab
        </h2>
        <p className="text-xs sm:text-sm text-stone-300">
          Design your own chaotic masterpiece like Golu did on Day 1, and let the AI client give you a savage utility bill critique!
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Design Controls */}
        <div className="lg:col-span-5 bg-stone-900 rounded-3xl p-6 border border-stone-800 space-y-5 shadow-xl">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <span>🎨</span>
            <span>Golu&apos;s Design Controls</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block text-stone-300 font-semibold mb-1">
                Poster Headline / Event:
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-stone-800 border border-stone-700 rounded-xl px-3 py-2 text-white font-medium focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-stone-300 font-semibold mb-1">
                Chaotic Sub-Headline:
              </label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full bg-stone-800 border border-stone-700 rounded-xl px-3 py-2 text-white font-medium focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-stone-300 font-semibold mb-1">
                Color &amp; Vibe Theme:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: "disco", label: "🕺 Cosmic Disco Pizza" },
                  { id: "bill", label: "⚡ Authentic Utility Bill" },
                  { id: "neon", label: "🌟 Neon Chaos 90s" },
                  { id: "chaos", label: "🔥 Maximum Clutter" },
                ].map((th) => (
                  <button
                    key={th.id}
                    onClick={() => setTheme(th.id as any)}
                    className={`p-2 rounded-xl border text-left font-bold transition-all ${
                      theme === th.id
                        ? "bg-amber-500/20 border-amber-500 text-amber-300"
                        : "bg-stone-800/60 border-stone-700 text-stone-400 hover:text-white"
                    }`}
                  >
                    {th.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="block text-stone-300 font-semibold mb-1">
                  Meter / Account #:
                </label>
                <input
                  type="text"
                  value={meterNo}
                  onChange={(e) => setMeterNo(e.target.value)}
                  className="w-full bg-stone-800 border border-stone-700 rounded-xl px-3 py-2 text-white font-medium focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-stone-300 font-semibold mb-1">
                  Payable Amount:
                </label>
                <input
                  type="text"
                  value={payableAmount}
                  onChange={(e) => setPayableAmount(e.target.value)}
                  className="w-full bg-stone-800 border border-stone-700 rounded-xl px-3 py-2 text-white font-medium focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-stone-300">
                <input
                  type="checkbox"
                  checked={hasElectricWarning}
                  onChange={(e) => setHasElectricWarning(e.target.checked)}
                  className="rounded bg-stone-800 border-stone-700 text-amber-500"
                />
                <span>Include Overdue Fine Warning &amp; Barcode</span>
              </label>
            </div>

            <div className="pt-2">
              <button
                onClick={handleGenerateRoast}
                disabled={isLoadingRoast}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-rose-500 via-orange-500 to-amber-500 hover:from-rose-400 hover:to-orange-400 text-stone-950 font-black flex items-center justify-center gap-2 shadow-lg transition-all"
              >
                {isLoadingRoast ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Client Analyzing Bill Likeness...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4" />
                    <span>Submit to Client for Roast!</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Live Poster Preview + Client Roast Card */}
        <div className="lg:col-span-7 space-y-6">
          {/* Live Poster Card */}
          <div
            className={`p-6 sm:p-8 rounded-3xl border-4 transition-all shadow-2xl relative overflow-hidden ${
              theme === "bill"
                ? "bg-stone-100 text-stone-950 border-stone-400 font-mono"
                : theme === "neon"
                ? "bg-slate-950 text-emerald-400 border-cyan-400 font-sans shadow-cyan-500/20"
                : theme === "chaos"
                ? "bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 text-stone-950 border-amber-300 font-serif"
                : "bg-stone-950 text-white border-yellow-400 shadow-yellow-500/20"
            }`}
          >
            {/* Poster Header */}
            <div className="border-b-2 border-dashed border-current pb-4 text-center space-y-1">
              <div className="flex justify-between items-center text-[11px] opacity-80 font-bold uppercase">
                <span>ELECTRIC UTILITY / PROMO NOTICE</span>
                <span>CONSUMER: GOLU THE CROREPATI</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black tracking-wider uppercase drop-shadow-md">
                {title || "UNTITLED POSTER BILL"}
              </h1>
              <p className="text-xs sm:text-sm font-extrabold uppercase tracking-widest text-amber-500">
                {tagline || "SPECIAL EDITION"}
              </p>
            </div>

            {/* Poster Body */}
            <div className="py-6 grid grid-cols-2 gap-4 text-xs">
              <div className="p-3 rounded-xl bg-black/10 border border-current/20 space-y-1">
                <span className="font-bold block uppercase opacity-75">Meter Reference:</span>
                <span className="font-mono text-sm font-bold">{meterNo}</span>
                <span className="text-[10px] block opacity-75">Units: {unitsConsumed}</span>
              </div>

              <div className="p-3 rounded-xl bg-black/10 border border-current/20 space-y-1 text-right">
                <span className="font-bold block uppercase opacity-75">Payable Immediately:</span>
                <span className="font-mono text-lg font-black text-rose-500">
                  {payableAmount}
                </span>
                <span className="text-[10px] block opacity-75">Due Date: YESTERDAY</span>
              </div>
            </div>

            {/* Hilarious Design Clipart & Barcode */}
            <div className="flex items-center justify-between border-t-2 border-dashed border-current pt-4">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🍕</span>
                <span className="text-2xl">🧹</span>
                <span className="text-2xl">⚡</span>
                <span className="text-xs font-bold uppercase opacity-80">
                  Graphic Design 101 Certified
                </span>
              </div>

              {/* Faux Barcode */}
              <div className="flex items-end gap-0.5 h-8">
                {[3, 6, 2, 8, 4, 1, 7, 3, 5, 2, 8, 4, 6].map((w, i) => (
                  <div
                    key={i}
                    style={{ width: `${w * 2}px` }}
                    className="bg-current h-full"
                  />
                ))}
              </div>
            </div>

            {/* Stamp Badge */}
            <div className="absolute top-4 right-4 rotate-12 border-2 border-rose-500 text-rose-500 px-3 py-1 rounded text-xs font-black uppercase tracking-wider bg-white/90 shadow-md">
              BIJLI KA BILL?
            </div>
          </div>

          {/* Client Roast Review Box */}
          {clientRoast && (
            <div className="p-5 sm:p-6 rounded-3xl bg-stone-900 border border-stone-800 shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🧐</span>
                  <span className="text-sm font-bold text-white">Client Review:</span>
                </div>
                <div className="px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-black">
                  Bill Likeness: {clientRoast.billScore}% ⚡
                </div>
              </div>

              <blockquote className="text-stone-200 text-sm italic border-l-4 border-amber-500 pl-3 py-1">
                &quot;{clientRoast.roast}&quot;
              </blockquote>

              {clientRoast.ammiReaction && (
                <p className="text-xs text-rose-400 font-semibold">
                  {clientRoast.ammiReaction}
                </p>
              )}

              <div className="pt-2 flex justify-end">
                <button
                  onClick={handleSpeakRoast}
                  className="flex items-center gap-2 text-xs font-bold px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-amber-400 border border-stone-700 transition-colors"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen to Client Roast (Gemini TTS)</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
