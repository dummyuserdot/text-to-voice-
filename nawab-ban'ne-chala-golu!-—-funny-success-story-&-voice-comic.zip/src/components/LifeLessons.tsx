import React, { useState } from "react";
import { Volume2, Play, Pause, Sparkles, CheckCircle2, ArrowRight } from "lucide-react";
import { FIVE_GOLDEN_RULES } from "../data/storyData";
import { playGeminiTTS, stopAudio } from "../utils/audioService";

interface LifeLessonsProps {
  lang: "roman" | "urdu" | "english";
  isAudioPlaying: boolean;
  setIsAudioPlaying: (playing: boolean) => void;
}

export const LifeLessons: React.FC<LifeLessonsProps> = ({
  lang,
  isAudioPlaying,
  setIsAudioPlaying,
}) => {
  const [isPlayingPunchline, setIsPlayingPunchline] = useState(false);

  const iconicDialogueRoman =
    "“Bhai, ameer banna hai to kaam karna parega… kyun ke ATM machine bhi bina card ke paisa nahi deti, aur Ammi bina kaam ke pocket money nahi detin!” 🤣🤣🤣";

  const iconicDialogueUrdu =
    "«بھائی، امیر بننا ہے تو کام کرنا پڑے گا… کیونکہ اے ٹی ایم مشین بھی بنا کارڈ کے پیسہ نہیں دیتی، اور امی بنا کام کے پاکٹ منی نہیں دیتیں!» 🤣🤣🤣";

  const iconicDialogueEnglish =
    "“Bro, if you want to become wealthy, you gotta work... because even an ATM won't spit cash without an inserted card, and Mom will never give pocket money without chores!” 🤣🤣🤣";

  const handlePlayDialogue = async () => {
    if (isPlayingPunchline) {
      stopAudio();
      setIsPlayingPunchline(false);
      setIsAudioPlaying(false);
      return;
    }

    setIsPlayingPunchline(true);
    setIsAudioPlaying(true);

    try {
      await playGeminiTTS(
        {
          text:
            "Aur Golu ka aakhri golden dialogue: 'Bhai, ameer banna hai to kaam karna parega! Kyun ke ATM machine bhi bina card ke paisa nahi deti, aur Ammi bina kaam ke pocket money nahi detin!' <laugh> Moral of the story: Khuwab billionaire ke dekho, lekin kaam Monday se nahi, AAJ se shuru karo!",
          voiceName: "Zephyr",
          speaker: "Golu",
          style: "Philosophical, energetic, hilarious stand-up comedy delivery with passionate laughter",
        },
        () => {
          setIsPlayingPunchline(true);
          setIsAudioPlaying(true);
        },
        () => {
          setIsPlayingPunchline(false);
          setIsAudioPlaying(false);
        },
        () => {
          setIsPlayingPunchline(false);
          setIsAudioPlaying(false);
        }
      );
    } catch {
      setIsPlayingPunchline(false);
      setIsAudioPlaying(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Hero Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Real World Freelance &amp; Life Truths</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-black text-white">
          🔥 Kahani Ka Funny Lekin Asli Lesson
        </h2>
        <p className="text-sm sm:text-base text-stone-300">
          Golu learned the hard way so you don&apos;t have to get roasted by Ammi or client bills!
        </p>
      </div>

      {/* 5 Golden Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {FIVE_GOLDEN_RULES.map((rule, idx) => (
          <div
            key={idx}
            className="p-5 rounded-2xl bg-stone-900 border border-stone-800 hover:border-amber-500/40 transition-all shadow-lg flex flex-col justify-between group hover:-translate-y-1"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-3xl p-2 rounded-2xl bg-stone-800 border border-stone-700/50 shadow-inner group-hover:scale-110 transition-transform">
                  {rule.icon}
                </span>
                <span className="text-xs font-black px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  Sabaq #{idx + 1}
                </span>
              </div>

              <h3
                className={`text-base sm:text-lg font-bold text-white group-hover:text-amber-300 transition-colors ${
                  lang === "urdu" ? "font-serif text-right text-lg" : ""
                }`}
              >
                {lang === "urdu"
                  ? rule.ruleUrdu
                  : lang === "english"
                  ? rule.ruleEnglish
                  : rule.ruleRoman}
              </h3>

              <p className="text-xs sm:text-sm text-stone-400 leading-relaxed">
                {rule.explanation}
              </p>
            </div>

            <div className="pt-4 mt-3 border-t border-stone-800/80 flex items-center justify-between text-xs text-stone-500">
              <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Proven in Practice</span>
              </span>
              <span className="text-stone-400 font-mono text-[11px]">Rule 0{idx + 1}</span>
            </div>
          </div>
        ))}

        {/* Bonus 6th Card: Action Card */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/20 via-orange-500/10 to-stone-900 border border-amber-500/30 flex flex-col justify-between shadow-xl">
          <div className="space-y-3">
            <span className="text-3xl p-2 rounded-2xl bg-amber-500/20 inline-block border border-amber-500/30">
              ⚡
            </span>
            <h3 className="text-lg font-black text-amber-300">
              The Monday Syndrome Cure
            </h3>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
              &quot;Main agle Monday se freelancing shuru karoonga&quot; is the biggest trap in the universe. Open your laptop and make your first bad design or code line right now!
            </p>
          </div>
          <div className="pt-4 mt-3 border-t border-amber-500/20">
            <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
              <span>Start Today, Not Monday</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </div>

      {/* Golu's Iconic Golden Punchline Banner */}
      <div className="relative p-6 sm:p-10 rounded-3xl bg-gradient-to-r from-stone-900 via-stone-850 to-stone-900 border-2 border-amber-500/50 shadow-2xl overflow-hidden">
        {/* Decorative background glow */}
        <div className="absolute -top-16 -right-16 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-48 h-48 bg-orange-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-extrabold uppercase">
              <span>👑 Golu&apos;s Grand Moral Dialogue</span>
            </div>

            <p
              className={`text-lg sm:text-2xl font-black text-white italic tracking-tight leading-snug ${
                lang === "urdu" ? "font-serif text-right text-2xl leading-relaxed" : ""
              }`}
            >
              {lang === "urdu"
                ? iconicDialogueUrdu
                : lang === "english"
                ? iconicDialogueEnglish
                : iconicDialogueRoman}
            </p>

            <p className="text-xs sm:text-sm text-amber-400 font-bold">
              🔥 Moral: Khuwab billionaire ke dekho, lekin kaam Monday se nahi — AAJ se shuru karo!
            </p>
          </div>

          {/* Audio Action Button */}
          <div className="flex flex-col items-center gap-2">
            <button
              onClick={handlePlayDialogue}
              className={`p-5 rounded-2xl font-black flex items-center gap-3 transition-all shadow-xl ${
                isPlayingPunchline
                  ? "bg-rose-500 text-white shadow-rose-500/30 scale-105"
                  : "bg-gradient-to-tr from-amber-400 via-orange-500 to-amber-500 hover:from-amber-300 hover:to-orange-400 text-stone-950 shadow-orange-500/40 hover:scale-105"
              }`}
            >
              {isPlayingPunchline ? (
                <>
                  <Pause className="w-6 h-6 fill-current" />
                  <span className="text-sm font-extrabold">Stop Voice</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-6 h-6" />
                  <span className="text-sm font-extrabold">Listen with Gemini TTS</span>
                </>
              )}
            </button>
            <span className="text-[11px] text-stone-400">Speaker: Golu • Voice: Zephyr</span>
          </div>
        </div>
      </div>
    </div>
  );
};
