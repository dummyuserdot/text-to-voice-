import React from "react";
import { Volume2, Sparkles, BookOpen, MessageSquare, Palette, Music } from "lucide-react";

interface HeaderProps {
  currentTab: "story" | "lessons" | "ask" | "poster" | "soundboard";
  setCurrentTab: (tab: "story" | "lessons" | "ask" | "poster" | "soundboard") => void;
  lang: "roman" | "urdu" | "english";
  setLang: (lang: "roman" | "urdu" | "english") => void;
  isAudioPlaying: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  lang,
  setLang,
  isAudioPlaying,
}) => {
  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-stone-900/90 border-b border-amber-500/20 shadow-xl transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500 flex items-center justify-center text-2xl shadow-lg shadow-orange-500/30 transform hover:scale-105 transition-transform cursor-pointer">
              😂
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-1.5">
                  <span>Nawab Ban&apos;ne Chala</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-400 to-yellow-300">
                    Golu!
                  </span>
                  <span className="text-sm px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-medium">
                    💸 ₹5,000
                  </span>
                </h1>
              </div>
              <p className="text-xs text-stone-400 hidden sm:block">
                The Hilarious Success Story & Voice Comic Theater
              </p>
            </div>
          </div>

          {/* Right Action: TTS Live Badge & Language Switcher */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Gemini TTS Indicator */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-800/80 border border-stone-700 text-xs text-stone-300 shadow-sm">
              <span className={`w-2 h-2 rounded-full ${isAudioPlaying ? "bg-emerald-400 animate-ping" : "bg-amber-400"}`} />
              <Volume2 className={`w-3.5 h-3.5 ${isAudioPlaying ? "text-emerald-400" : "text-amber-400"}`} />
              <span className="font-semibold text-amber-300">Gemini 3.8 TTS</span>
            </div>

            {/* Language Selector */}
            <div className="flex bg-stone-800 p-0.5 rounded-xl border border-stone-700 text-xs font-semibold">
              <button
                onClick={() => setLang("roman")}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  lang === "roman"
                    ? "bg-amber-500 text-stone-950 font-bold shadow"
                    : "text-stone-300 hover:text-white"
                }`}
                title="Roman Urdu / Hindi"
              >
                Roman Urdu
              </button>
              <button
                onClick={() => setLang("urdu")}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  lang === "urdu"
                    ? "bg-amber-500 text-stone-950 font-bold shadow"
                    : "text-stone-300 hover:text-white"
                }`}
                title="Urdu Script"
              >
                اردو
              </button>
              <button
                onClick={() => setLang("english")}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  lang === "english"
                    ? "bg-amber-500 text-stone-950 font-bold shadow"
                    : "text-stone-300 hover:text-white"
                }`}
                title="English Translation"
              >
                English
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 sm:gap-2 mt-3 overflow-x-auto scrollbar-none pb-1">
          <button
            onClick={() => setCurrentTab("story")}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
              currentTab === "story"
                ? "bg-gradient-to-r from-amber-500 to-orange-500 text-stone-950 shadow-md shadow-amber-500/20 font-bold"
                : "bg-stone-800/70 text-stone-300 hover:bg-stone-800 hover:text-white border border-stone-700/60"
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Story Cinema</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-stone-950/20 font-bold">6 Scenes</span>
          </button>

          <button
            onClick={() => setCurrentTab("lessons")}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
              currentTab === "lessons"
                ? "bg-gradient-to-r from-amber-500 to-orange-500 text-stone-950 shadow-md font-bold"
                : "bg-stone-800/70 text-stone-300 hover:bg-stone-800 hover:text-white border border-stone-700/60"
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>5 Golden Sabaq</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-stone-950/20 font-bold">Moral</span>
          </button>

          <button
            onClick={() => setCurrentTab("ask")}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
              currentTab === "ask"
                ? "bg-gradient-to-r from-amber-500 to-orange-500 text-stone-950 shadow-md font-bold"
                : "bg-stone-800/70 text-stone-300 hover:bg-stone-800 hover:text-white border border-stone-700/60"
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Ask Golu &amp; Ammi</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-stone-950/20 font-bold">AI Chat</span>
          </button>

          <button
            onClick={() => setCurrentTab("poster")}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
              currentTab === "poster"
                ? "bg-gradient-to-r from-amber-500 to-orange-500 text-stone-950 shadow-md font-bold"
                : "bg-stone-800/70 text-stone-300 hover:bg-stone-800 hover:text-white border border-stone-700/60"
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>Bijli Bill Poster Lab</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 font-bold">Meme</span>
          </button>

          <button
            onClick={() => setCurrentTab("soundboard")}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
              currentTab === "soundboard"
                ? "bg-gradient-to-r from-amber-500 to-orange-500 text-stone-950 shadow-md font-bold"
                : "bg-stone-800/70 text-stone-300 hover:bg-stone-800 hover:text-white border border-stone-700/60"
            }`}
          >
            <Music className="w-4 h-4" />
            <span>Desi Soundboard</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-bold">SFX</span>
          </button>
        </div>
      </div>
    </header>
  );
};
