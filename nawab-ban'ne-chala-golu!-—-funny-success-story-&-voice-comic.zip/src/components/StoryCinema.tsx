import React, { useState } from "react";
import confetti from "canvas-confetti";
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  Zap,
  CheckCircle2,
  Quote,
  Loader2,
} from "lucide-react";
import { StoryScene, STORY_SCENES } from "../data/storyData";
import { playGeminiTTS, stopAudio, playSynthesizedSfx } from "../utils/audioService";

interface StoryCinemaProps {
  lang: "roman" | "urdu" | "english";
  isAudioPlaying: boolean;
  setIsAudioPlaying: (playing: boolean) => void;
}

export const StoryCinema: React.FC<StoryCinemaProps> = ({
  lang,
  isAudioPlaying,
  setIsAudioPlaying,
}) => {
  const [activeSceneIndex, setActiveSceneIndex] = useState(0);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [activeSpeaker, setActiveSpeaker] = useState<string | null>(null);
  const [autoPlayNext, setAutoPlayNext] = useState(false);

  const scene = STORY_SCENES[activeSceneIndex];

  const handlePlaySceneNarration = async (sceneToPlay: StoryScene = scene) => {
    if (isAudioPlaying) {
      stopAudio();
      setIsAudioPlaying(false);
      setActiveSpeaker(null);
      return;
    }

    setIsLoadingAudio(true);
    setActiveSpeaker("Narrator");

    // Trigger scene celebratory confetti on Scene 5 (5,000 Rs)
    if (sceneToPlay.id === 5) {
      triggerConfetti();
    }

    try {
      await playGeminiTTS(
        {
          text: sceneToPlay.ttsScript,
          voiceName: "Puck",
          speaker: "Narrator",
          style: "Dramatic, energetic comedy storyteller speaking Roman Urdu with expressive laughter and comedic pauses",
        },
        () => {
          setIsLoadingAudio(false);
          setIsAudioPlaying(true);
        },
        () => {
          setIsAudioPlaying(false);
          setActiveSpeaker(null);
          if (autoPlayNext && activeSceneIndex < STORY_SCENES.length - 1) {
            handleSelectScene(activeSceneIndex + 1);
          }
        },
        () => {
          setIsLoadingAudio(false);
          setIsAudioPlaying(false);
          setActiveSpeaker(null);
        }
      );
    } catch (err) {
      console.error(err);
      setIsLoadingAudio(false);
      setIsAudioPlaying(false);
      setActiveSpeaker(null);
    }
  };

  const handlePlayDialogue = async (lineText: string, speaker: string, voiceName: any) => {
    stopAudio();
    setIsLoadingAudio(true);
    setActiveSpeaker(speaker);

    try {
      await playGeminiTTS(
        {
          text: lineText,
          voiceName: voiceName || (speaker === "Ammi" ? "Kore" : speaker === "Client" ? "Charon" : "Zephyr"),
          speaker,
          style:
            speaker === "Ammi"
              ? "Strict, humorous desi mother ready with a broom, sharp comedic tone"
              : speaker === "Client"
              ? "Confused, deadpan client looking at a chaotic poster"
              : "Energetic, dramatic young guy Golu with expressive comedic timing",
        },
        () => {
          setIsLoadingAudio(false);
          setIsAudioPlaying(true);
        },
        () => {
          setIsAudioPlaying(false);
          setActiveSpeaker(null);
        },
        () => {
          setIsLoadingAudio(false);
          setIsAudioPlaying(false);
          setActiveSpeaker(null);
        }
      );
    } catch {
      setIsLoadingAudio(false);
      setIsAudioPlaying(false);
      setActiveSpeaker(null);
    }
  };

  const handleSelectScene = (index: number) => {
    stopAudio();
    setIsAudioPlaying(false);
    setActiveSpeaker(null);
    setActiveSceneIndex(index);
    if (STORY_SCENES[index].id === 5) {
      triggerConfetti();
    }
  };

  const triggerConfetti = () => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ["#f59e0b", "#10b981", "#ec4899", "#3b82f6"],
    });
  };

  const getSceneText = () => {
    if (lang === "urdu") return scene.fullNarrationUrdu;
    if (lang === "english") return scene.fullNarrationEnglish;
    return scene.fullNarrationRoman;
  };

  const getSceneTitle = () => {
    if (lang === "urdu") return scene.titleUrdu;
    if (lang === "english") return scene.titleEnglish;
    return scene.titleRoman;
  };

  return (
    <div className="space-y-6">
      {/* Chapter Stepper */}
      <div className="bg-stone-900/80 rounded-2xl p-2 sm:p-3 border border-stone-800 shadow-lg">
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {STORY_SCENES.map((item, idx) => {
            const isActive = idx === activeSceneIndex;
            return (
              <button
                key={item.id}
                onClick={() => handleSelectScene(idx)}
                className={`flex flex-col text-left p-2.5 rounded-xl transition-all border ${
                  isActive
                    ? "bg-gradient-to-br from-amber-500/20 to-orange-500/10 border-amber-500 text-amber-300 shadow-md scale-[1.02]"
                    : "bg-stone-800/40 border-stone-800 text-stone-400 hover:bg-stone-800 hover:text-stone-200"
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400">
                    {item.chapter}
                  </span>
                  {item.id === 5 && (
                    <span className="text-[10px] px-1 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                      ₹5K
                    </span>
                  )}
                </div>
                <span className="text-xs font-bold line-clamp-1 text-white">
                  {lang === "urdu" ? item.titleUrdu : item.titleRoman}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Cinema Card */}
      <div className="bg-stone-900 rounded-3xl border border-stone-800 overflow-hidden shadow-2xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
          {/* Left Column: Visual Artwork & Comic Illustration */}
          <div className="lg:col-span-7 relative bg-stone-950 flex flex-col justify-center min-h-[340px] sm:min-h-[420px] overflow-hidden group">
            <img
              src={scene.image}
              alt={scene.imageAlt}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            {/* Visual gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/20 to-transparent pointer-events-none" />

            {/* Floating Chapter Badge */}
            <div className="absolute top-4 left-4 flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-stone-950/80 backdrop-blur-md border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1.5 shadow-lg">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                {scene.chapter} • Scene {scene.id} of 6
              </span>
            </div>

            {/* Sound Effect Quick Pill */}
            <div className="absolute top-4 right-4">
              <button
                onClick={() => {
                  if (scene.id === 2) playSynthesizedSfx("jhaaru");
                  else if (scene.id === 4) playSynthesizedSfx("bruh");
                  else if (scene.id === 5) playSynthesizedSfx("kaching");
                  else playSynthesizedSfx("cheer");
                }}
                className="px-3 py-1 rounded-full bg-stone-950/80 backdrop-blur-md border border-stone-700 text-stone-300 text-xs font-medium hover:border-amber-400 hover:text-white transition-all flex items-center gap-1 shadow-lg cursor-pointer"
                title="Tap to trigger scene sound effect"
              >
                <Zap className="w-3 h-3 text-amber-400" />
                <span>{scene.soundEffect}</span>
              </button>
            </div>

            {/* Bottom Caption Pill */}
            <div className="absolute bottom-4 left-4 right-4 bg-stone-900/90 backdrop-blur-md p-3 rounded-2xl border border-stone-700/80 shadow-xl">
              <p className="text-sm font-bold text-amber-300 italic flex items-center gap-2">
                <span>💬</span> {scene.tagline}
              </p>
            </div>
          </div>

          {/* Right Column: Story Text, Audio Controls & Interactive Dialogues */}
          <div className="lg:col-span-5 p-5 sm:p-7 flex flex-col justify-between bg-stone-900/95">
            <div className="space-y-4">
              {/* Scene Title */}
              <div>
                <h2
                  className={`text-xl sm:text-2xl font-black text-white leading-tight ${
                    lang === "urdu" ? "font-serif text-right text-2xl" : ""
                  }`}
                >
                  {getSceneTitle()}
                </h2>
              </div>

              {/* Main Narration Box */}
              <div
                className={`p-4 rounded-2xl bg-stone-800/60 border border-stone-700/70 text-stone-200 text-sm sm:text-base leading-relaxed ${
                  lang === "urdu" ? "text-right font-serif text-lg leading-loose" : ""
                }`}
              >
                {getSceneText()}
              </div>

              {/* Character Dialogues */}
              {scene.dialogues && scene.dialogues.length > 0 && (
                <div className="space-y-2.5 pt-2">
                  <h4 className="text-xs uppercase tracking-wider font-extrabold text-stone-400 flex items-center gap-1.5">
                    <Quote className="w-3.5 h-3.5 text-amber-400" />
                    <span>Character Dialogues (Tap to listen)</span>
                  </h4>
                  <div className="space-y-2">
                    {scene.dialogues.map((dlg, dIdx) => {
                      const isSpeaking = activeSpeaker === dlg.speaker && isAudioPlaying;
                      const textToRead =
                        lang === "urdu"
                          ? dlg.textUrdu
                          : lang === "english"
                          ? dlg.textEnglish
                          : dlg.textRoman;

                      return (
                        <div
                          key={dIdx}
                          className={`p-3 rounded-xl border transition-all ${
                            isSpeaking
                              ? "bg-amber-500/10 border-amber-500/50 shadow-md ring-1 ring-amber-500/30"
                              : "bg-stone-800/40 border-stone-800 hover:bg-stone-800/70"
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span
                              className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                                dlg.speaker === "Ammi"
                                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                                  : dlg.speaker === "Golu"
                                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                                  : dlg.speaker === "Client"
                                  ? "bg-purple-500/20 text-purple-300 border border-purple-500/30"
                                  : "bg-blue-500/20 text-blue-300 border border-blue-500/30"
                              }`}
                            >
                              {dlg.speaker}
                            </span>
                            <button
                              onClick={() => handlePlayDialogue(dlg.textRoman, dlg.speaker, dlg.voiceName)}
                              className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold px-2 py-0.5 rounded-lg hover:bg-amber-400/10 transition-colors"
                            >
                              {isSpeaking ? (
                                <>
                                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                                  <span>Speaking...</span>
                                </>
                              ) : (
                                <>
                                  <Volume2 className="w-3.5 h-3.5" />
                                  <span>Voice</span>
                                </>
                              )}
                            </button>
                          </div>
                          <p
                            className={`text-xs sm:text-sm text-stone-200 ${
                              lang === "urdu" ? "text-right font-serif text-base" : ""
                            }`}
                          >
                            {textToRead}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Funny Trivia / Reality Check */}
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200/90 flex items-start gap-2">
                <span className="text-base">💡</span>
                <div>
                  <span className="font-bold text-amber-300">Golu Fact: </span>
                  <span>{scene.funnyFact}</span>
                </div>
              </div>
            </div>

            {/* Bottom Actions: Gemini TTS Narration & Scene Navigation */}
            <div className="pt-6 mt-4 border-t border-stone-800 space-y-3">
              {/* Play Scene Voice with Gemini 3.8 Flash TTS */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handlePlaySceneNarration(scene)}
                  disabled={isLoadingAudio}
                  className={`flex-1 py-3 px-5 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg transition-all ${
                    isAudioPlaying && activeSpeaker === "Narrator"
                      ? "bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/20"
                      : "bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-stone-950 shadow-orange-500/30"
                  }`}
                >
                  {isLoadingAudio ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Gemini TTS Generating Voice...</span>
                    </>
                  ) : isAudioPlaying && activeSpeaker === "Narrator" ? (
                    <>
                      <Pause className="w-5 h-5 fill-current" />
                      <span>Pause Narration</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 fill-current" />
                      <span>Listen to Scene (Gemini 3.8 Flash TTS)</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => {
                    stopAudio();
                    setIsAudioPlaying(false);
                    setActiveSpeaker(null);
                  }}
                  className="p-3 rounded-2xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white border border-stone-700 transition-colors"
                  title="Stop audio"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>
              </div>

              {/* Scene Navigation Prev / Next */}
              <div className="flex items-center justify-between text-xs text-stone-400 pt-1">
                <button
                  onClick={() => handleSelectScene(Math.max(0, activeSceneIndex - 1))}
                  disabled={activeSceneIndex === 0}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-stone-800/80 hover:bg-stone-800 disabled:opacity-30 disabled:cursor-not-allowed text-stone-200 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous Scene</span>
                </button>

                <label className="flex items-center gap-1.5 cursor-pointer select-none text-stone-400 hover:text-stone-300">
                  <input
                    type="checkbox"
                    checked={autoPlayNext}
                    onChange={(e) => setAutoPlayNext(e.target.checked)}
                    className="rounded bg-stone-800 border-stone-700 text-amber-500 focus:ring-0"
                  />
                  <span>Auto-advance</span>
                </label>

                <button
                  onClick={() =>
                    handleSelectScene(Math.min(STORY_SCENES.length - 1, activeSceneIndex + 1))
                  }
                  disabled={activeSceneIndex === STORY_SCENES.length - 1}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-stone-800/80 hover:bg-stone-800 disabled:opacity-30 disabled:cursor-not-allowed text-stone-200 transition-colors"
                >
                  <span>Next Scene</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
