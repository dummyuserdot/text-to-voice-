import React, { useState } from "react";
import { Music, Volume2, Sparkles } from "lucide-react";
import { FUNNY_SOUND_EFFECTS } from "../data/storyData";
import { playSynthesizedSfx } from "../utils/audioService";

export const Soundboard: React.FC = () => {
  const [activeEffect, setActiveEffect] = useState<string | null>(null);

  const handlePlaySound = (id: string) => {
    setActiveEffect(id);
    playSynthesizedSfx(id);
    setTimeout(() => {
      setActiveEffect(null);
    }, 600);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Intro */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
          <Music className="w-3.5 h-3.5" />
          <span>Interactive Audio Meme Board</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white">
          🎵 Desi Comedy Soundboard
        </h2>
        <p className="text-xs sm:text-sm text-stone-300">
          Tap any button to play iconic sound effects instantly via Web Audio!
        </p>
      </div>

      {/* Grid of Sound Buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {FUNNY_SOUND_EFFECTS.map((sfx) => {
          const isActive = activeEffect === sfx.id;
          return (
            <button
              key={sfx.id}
              onClick={() => handlePlaySound(sfx.id)}
              className={`p-6 rounded-3xl border flex flex-col items-center justify-center text-center gap-3 transition-all transform cursor-pointer ${
                isActive
                  ? "bg-amber-500 text-stone-950 border-amber-400 scale-95 shadow-xl shadow-amber-500/40"
                  : "bg-stone-900 border-stone-800 text-stone-200 hover:border-amber-500/50 hover:bg-stone-850 hover:scale-[1.02] shadow-lg"
              }`}
            >
              <span className="text-4xl filter drop-shadow-md">{sfx.emoji}</span>
              <div>
                <h4 className="text-sm sm:text-base font-black">{sfx.name}</h4>
                <p
                  className={`text-[11px] mt-0.5 line-clamp-2 ${
                    isActive ? "text-stone-900 font-bold" : "text-stone-400"
                  }`}
                >
                  {sfx.desc}
                </p>
              </div>

              <div
                className={`flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  isActive
                    ? "bg-stone-950/20 text-stone-950"
                    : "bg-stone-800 text-stone-400"
                }`}
              >
                <Volume2 className="w-3 h-3" />
                <span>Tap to Play</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Ammi's Warning Footer */}
      <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-center text-xs text-rose-300">
        <span>⚠️ </span>
        <strong>Ammi Warning: </strong>
        <span>
          Excessive use of sound effects without doing your actual daily work may attract emergency broomstick deployment! 🧹😂
        </span>
      </div>
    </div>
  );
};
