import React, { useState } from "react";
import { Header } from "./components/Header";
import { StoryCinema } from "./components/StoryCinema";
import { LifeLessons } from "./components/LifeLessons";
import { AskCharacters } from "./components/AskCharacters";
import { PosterMemeStudio } from "./components/PosterMemeStudio";
import { Soundboard } from "./components/Soundboard";

export default function App() {
  const [currentTab, setCurrentTab] = useState<
    "story" | "lessons" | "ask" | "poster" | "soundboard"
  >("story");
  const [lang, setLang] = useState<"roman" | "urdu" | "english">("roman");
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col font-sans selection:bg-amber-500 selection:text-stone-950">
      {/* Header with Navigation and Audio indicator */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        lang={lang}
        setLang={setLang}
        isAudioPlaying={isAudioPlaying}
      />

      {/* Main Tabbed Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {currentTab === "story" && (
          <StoryCinema
            lang={lang}
            isAudioPlaying={isAudioPlaying}
            setIsAudioPlaying={setIsAudioPlaying}
          />
        )}

        {currentTab === "lessons" && (
          <LifeLessons
            lang={lang}
            isAudioPlaying={isAudioPlaying}
            setIsAudioPlaying={setIsAudioPlaying}
          />
        )}

        {currentTab === "ask" && <AskCharacters />}

        {currentTab === "poster" && <PosterMemeStudio />}

        {currentTab === "soundboard" && <Soundboard />}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-stone-800/80 bg-stone-900/60 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-400">
          <div className="flex items-center gap-2">
            <span className="text-lg">💸</span>
            <span className="font-bold text-stone-300">
              Nawab Ban&apos;ne Chala Golu!
            </span>
            <span>— The Freelancing Comedy Success Story</span>
          </div>

          <div className="text-center sm:text-right text-stone-400">
            <span>Powered by </span>
            <strong className="text-amber-400 font-semibold">Gemini 3.8 Flash TTS</strong>
            <span> • Dream like a billionaire, start work TODAY! 🔥</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
