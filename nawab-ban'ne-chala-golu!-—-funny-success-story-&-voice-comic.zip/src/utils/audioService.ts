/**
 * Audio Service for Nawab Ban'ne Chala Golu
 * Integrates Gemini 3.8 Flash TTS via server endpoint /api/tts
 * Includes in-memory caching, Web Speech fallback, and Web Audio SFX soundboard synthesizer
 */

const audioCache = new Map<string, string>(); // Cache key -> data:audio/wav;base64,...
let currentAudio: HTMLAudioElement | null = null;

export interface TTSOptions {
  text: string;
  voiceName?: "Puck" | "Kore" | "Fenrir" | "Zephyr" | "Charon";
  style?: string;
  speaker?: string;
  multiSpeaker?: {
    speakers: { name: string; voiceName: string }[];
    lines: { speaker: string; text: string; style?: string }[];
  };
}

/**
 * Play text using Gemini 3.8 Flash TTS via /api/tts
 */
export async function playGeminiTTS(
  options: TTSOptions,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: (err: any) => void
): Promise<HTMLAudioElement | null> {
  stopAudio();

  const cacheKey = JSON.stringify({
    text: options.text,
    voice: options.voiceName || "Puck",
    speaker: options.speaker,
  });

  try {
    let audioSrc = audioCache.get(cacheKey);

    if (!audioSrc) {
      const response = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(options),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `TTS request failed with status ${response.status}`);
      }

      const data = await response.json();
      if (!data.audio) {
        throw new Error("No audio payload returned from Gemini TTS");
      }

      audioSrc = `data:${data.mimeType || "audio/wav"};base64,${data.audio}`;
      audioCache.set(cacheKey, audioSrc);
    }

    const audio = new Audio(audioSrc);
    currentAudio = audio;

    audio.onplay = () => onStart?.();
    audio.onended = () => {
      currentAudio = null;
      onEnd?.();
    };
    audio.onerror = (e) => {
      console.warn("Audio playback error, falling back to speech synthesis:", e);
      fallbackToSpeechSynthesis(options.text, onStart, onEnd);
    };

    await audio.play();
    return audio;
  } catch (error: any) {
    console.warn("Gemini TTS failed, using Web Speech fallback:", error?.message);
    fallbackToSpeechSynthesis(options.text, onStart, onEnd);
    onError?.(error);
    return null;
  }
}

/**
 * Stop any ongoing audio playback
 */
export function stopAudio(): void {
  if (currentAudio) {
    currentAudio.pause();
    currentAudio.currentTime = 0;
    currentAudio = null;
  }
  if (typeof window !== "undefined" && window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
}

/**
 * Web Speech Synthesis fallback
 */
function fallbackToSpeechSynthesis(
  text: string,
  onStart?: () => void,
  onEnd?: () => void
): void {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    onEnd?.();
    return;
  }

  // Clean text from bracketed vocal directions e.g. <laugh> or <gasp>
  const cleanText = text.replace(/<[^>]+>/g, "").replace(/\|[^|]+\|/g, "");

  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.rate = 1.0;
  utterance.pitch = 1.1;

  // Prefer Urdu / Hindi or friendly English voice if available
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice =
    voices.find((v) => v.lang.startsWith("ur") || v.lang.startsWith("hi")) ||
    voices.find((v) => v.lang.startsWith("en-IN")) ||
    voices[0];

  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  utterance.onstart = () => onStart?.();
  utterance.onend = () => onEnd?.();
  utterance.onerror = () => onEnd?.();

  window.speechSynthesis.speak(utterance);
}

/**
 * Synthesizes hilarious meme sound effects on the fly with Web Audio API!
 */
export function playSynthesizedSfx(id: string): void {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();

    if (id === "jhaaru") {
      // Ammi's broom swoosh: filtered noise burst with frequency slide
      const bufferSize = ctx.sampleRate * 0.4;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(800, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(200, ctx.currentTime + 0.35);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.7, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.38);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      noise.start();
    } else if (id === "kaching") {
      // 5,000 Rs Ka-ching: coin chime pair
      [1046.5, 1318.5, 1567.98, 2093].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.08);

        gain.gain.setValueAtTime(0.3, ctx.currentTime + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.08 + 0.4);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.08);
        osc.stop(ctx.currentTime + idx * 0.08 + 0.45);
      });
    } else if (id === "bruh") {
      // Deep bass drop "Bruh / Emotional damage"
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(140, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(45, ctx.currentTime + 0.6);

      gain.gain.setValueAtTime(0.5, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.65);
    } else if (id === "bill") {
      // Bijli Ka Bill shock: electrical buzz
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "square";
      osc.frequency.setValueAtTime(220, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(440, ctx.currentTime + 0.15);
      osc.frequency.linearRampToValueAtTime(110, ctx.currentTime + 0.4);

      gain.gain.setValueAtTime(0.4, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.45);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.5);
    } else if (id === "cheer") {
      // Victory Fanfare arpeggio
      const notes = [523.25, 659.25, 783.99, 1046.5];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.12);

        gain.gain.setValueAtTime(0.35, ctx.currentTime + idx * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + idx * 0.12 + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.12);
        osc.stop(ctx.currentTime + idx * 0.12 + 0.55);
      });
    } else {
      // Default dramatic tone
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.setValueAtTime(300, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    }
  } catch (err) {
    console.warn("Sound effect synthesis note:", err);
  }
}
