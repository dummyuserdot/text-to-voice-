export interface DialogueLine {
  speaker: "Narrator" | "Golu" | "Ammi" | "Dost" | "Client";
  textRoman: string;
  textUrdu: string;
  textEnglish: string;
  voiceName: "Puck" | "Kore" | "Fenrir" | "Zephyr" | "Charon";
  style: string;
}

export interface StoryScene {
  id: number;
  titleRoman: string;
  titleUrdu: string;
  titleEnglish: string;
  chapter: string;
  tagline: string;
  image: string;
  imageAlt: string;
  bgGradient: string;
  accentColor: string;
  fullNarrationRoman: string;
  fullNarrationUrdu: string;
  fullUrduScript?: string;
  fullNarrationEnglish: string;
  ttsScript: string;
  soundEffect: string;
  dialogues: DialogueLine[];
  funnyFact: string;
}

export const STORY_SCENES: StoryScene[] = [
  {
    id: 1,
    chapter: "Chapter 1",
    titleRoman: "Subah Ke 12 Baje & Crorepati Dreams",
    titleUrdu: "صبح کے ۱۲ بجے اور کروڑ پتی بننے کا خواب",
    titleEnglish: "Waking at 12 PM & Billionaire Dreams",
    tagline: "“1 din mein crore pati kaise banein?” 🤣",
    image: "/src/assets/images/golu_daydreaming_crorepati_1791526026877.jpg",
    imageAlt: "Golu waking up at 12 PM dreaming of becoming a billionaire via YouTube",
    bgGradient: "from-amber-500/20 via-orange-500/10 to-transparent",
    accentColor: "border-amber-500 text-amber-500",
    fullNarrationRoman:
      "Ek dafa ka zikr hai, Golu naam ka aik larka tha. Uska khuwab tha ameer banna, lekin kaam karne se uski allergy thi! 😂 Golu subah 12 baje uthta, nashta karta aur mobile pakar kar YouTube par search karta: “1 din mein crore pati kaise banein?” 🤣",
    fullUrduScript: "ایک دفعہ کا ذکر ہے، گولو نام کا ایک لڑکا تھا۔ اس کا خواب تھا امیر بننا، لیکن کام کرنے سے اس کو الرجی تھی! گولو صبح بارہ بجے اٹھتا، ناشتہ کرتا اور موبائل پکڑ کر یوٹیوب پر سرچ کرتا: ایک دن میں کروڑ پتی کیسے بنیں؟",
    fullNarrationUrdu:
      "ایک دفعہ کا ذکر ہے، گولو نام کا ایک لڑکا تھا۔ اس کا خواب تھا امیر بننا، لیکن کام کرنے سے اس کو الرجی تھی! 😂 گولو صبح بارہ بجے اٹھتا، ناشتہ کرتا اور موبائل پکڑ کر یوٹیوب پر سرچ کرتا: «ایک دن میں کروڑ پتی کیسے بنیں؟» 🤣",
    fullNarrationEnglish:
      "Once upon a time, there was a boy named Golu. His dream was to become filthy rich, but he had a severe allergy to actual work! 😂 Golu would wake up at 12 in the afternoon, eat breakfast, grab his phone, and search on YouTube: 'How to become a billionaire in 1 day?' 🤣",
    ttsScript:
      "Ek dafa ka zikr hai! Golu naam ka aik larka tha. Uska khuwab tha ameer tareen banna, lekin kaam karne se usay sakht allergy thi! <laugh> Golu rozana dopahar 12 baje uthta, nashta karta aur mobile pakar kar YouTube par search karta: '1 din mein crore pati kaise banein?' Bhai, kya mast plan tha!",
    soundEffect: "Yawn & Alarm Snooze 😴",
    dialogues: [
      {
        speaker: "Narrator",
        textRoman: "Golu ka khuwab tha Forbes ki list mein sabse upar aana... bina bistar se uthe!",
        textUrdu: "گولو کا خواب تھا فوربز کی لسٹ میں سب سے اوپر آنا... بغیر بستر سے اٹھے!",
        textEnglish: "Golu's ambition was topping Forbes billionaires list... without leaving his cozy bed!",
        voiceName: "Puck",
        style: "Playful comedic narrator",
      },
      {
        speaker: "Golu",
        textRoman: "“Bas 1 din ki trick mil jaye, kal subah seedha Ferrari ka showroom jaunga!” 🏎️💨",
        textUrdu: "«بس ایک دن کی ٹرک مل جائے، کل صبح سیدھا فراری کے شوروم جاؤں گا!»",
        textEnglish: "“Just need that 1-day viral shortcut, tomorrow morning I'm heading straight to the Ferrari showroom!”",
        voiceName: "Zephyr",
        style: "Excited daydreamer",
      },
    ],
    funnyFact: "Golu had watched 342 motivational videos but hadn't made his own bed once in 3 years.",
  },
  {
    id: 2,
    chapter: "Chapter 2",
    titleRoman: "Ammi Ki Jhaaru Therapy: The Reality Check",
    titleUrdu: "امی کی جھاڑو تھراپی: حقیقت کا تھپڑ",
    titleEnglish: "Ammi's Broom Therapy: The Reality Check",
    tagline: "“Business mein risk to lena parta hai!” 💀🧹",
    image: "/src/assets/images/golu_ammi_jhaaru_1791526043673.jpg",
    imageAlt: "Ammi confronting Golu with a broomstick while he sweeps the floor",
    bgGradient: "from-rose-500/20 via-pink-500/10 to-transparent",
    accentColor: "border-rose-500 text-rose-500",
    fullNarrationRoman:
      "Ek din uski Ammi ne kaha: “Golu! Beta, kuch kaam bhi kar lo!” Golu bola: “Ammi, main billionaire banne ki planning kar raha hoon!” Ammi ne jhaaru uthaya aur kaha: “Achha! Pehle is ghar ka floor saaf kar, phir tujhe billionaire ki hawa lagwati hoon!” 😂😂 Golu ne socha, “Yaar, business mein risk to lena parta hai!” Aur foran jhaaru pakar liya. 💀",
    fullUrduScript: "ایک دن اس کی امی نے کہا: «گولو! بیٹا، کچھ کام بھی کر لو!» گولو بولا: «امی، میں بلینیئر بننے کی پلاننگ کر رہا ہوں!» امی نے جھاڑو اٹھایا اور کہا: «اچھا! پہلے اس گھر کا فرش صاف کر، پھر تجھے بلینیئر کی ہوا لگواتی ہوں!» گولو نے سوچا، «یار، بزنس میں رسک تو لینا پڑتا ہے!» اور فوراً جھاڑو پکڑ لیا۔",
    fullNarrationUrdu:
      "ایک دن اس کی امی نے کہا: «گولو! بیٹا، کچھ کام بھی کر لو!» گولو بولا: «امی، میں بلینیئر بننے کی پلاننگ کر رہا ہوں!» امی نے جھاڑو اٹھایا اور کہا: «اچھا! پہلے اس گھر کا فرش صاف کر، پھر تجھے بلینیئر کی ہوا لگواتی ہوں!» 😂😂 گولو نے سوچا، «یار، بزنس میں رسک تو لینا پڑتا ہے!» اور فوراً جھاڑو پکڑ لیا۔ 💀",
    fullNarrationEnglish:
      "One day his mom shouted: 'Golu! Son, do some actual work!' Golu replied smartly: 'Mom, I am planning how to become a billionaire!' Mom picked up the broom and said: 'Oh really! First sweep this floor, then I will blow billionaire air into you!' 😂😂 Golu thought: 'Well, one must take risks in business!' and quickly grabbed the broom. 💀",
    ttsScript:
      "Ek din uski Ammi ne aakar kaha: 'Golu! Beta, kuch kaam bhi kar lo!' Golu bola: 'Ammi! Main billionaire banne ki planning kar raha hoon!' Ammi ne jhaaru uthaya aur kaha: <gasp> 'Achha! Pehle is ghar ka floor saaf kar, phir tujhe billionaire ki hawa lagwati hoon!' Golu ne foran jhaaru pakar liya: 'Yaar, business mein risk to lena parta hai!'",
    soundEffect: "Jhaaru Swoosh & Emotional Damage 🧹",
    dialogues: [
      {
        speaker: "Ammi",
        textRoman: "“Golu! Beta, kuch kaam bhi kar lo! Kab tak YouTube par hawa mein mehal banayega?”",
        textUrdu: "«گولو! بیٹا، کچھ کام بھی کر لو! کب تک یوٹیوب پر ہوا میں محل بنائے گا؟»",
        textEnglish: "“Golu! Son, do some real work! How long will you build castles in the air on YouTube?”",
        voiceName: "Kore",
        style: "Strict witty South Asian mother with broom ready",
      },
      {
        speaker: "Golu",
        textRoman: "“Ammi, main billionaire banne ki planning kar raha hoon! CEO mindset hai mera!”",
        textUrdu: "«امی، میں بلینیئر بننے کی پلاننگ کر رہا ہوں! سی ای او مائنڈ سیٹ ہے میرا!»",
        textEnglish: "“Mom, I am strategizing to become a billionaire! It's called CEO mindset!”",
        voiceName: "Zephyr",
        style: "Proud and defensive",
      },
      {
        speaker: "Ammi",
        textRoman: "“Achha! Pehle is kamray ka jhaaru laga, phir tujhe billionaire ki hawa lagwati hoon!” 🧹🔥",
        textUrdu: "«اچھا! پہلے اس کمرے کا جھاڑو لگا، پھر تجھے بلینیئر کی ہوا لگواتی ہوں!»",
        textEnglish: "“Really! First sweep this floor clean, then I'll show you what billionaire air feels like!”",
        voiceName: "Kore",
        style: "Decisive commanding mom tone",
      },
      {
        speaker: "Golu",
        textRoman: "“Yaar, business mein risk to lena parta hai... chalo jhaaru hi sahi!” 💀",
        textUrdu: "«یار، بزنس میں رسک تو لینا پڑتا ہے... چلو جھاڑو ہی سہی!»",
        textEnglish: "“Well, calculated risks are part of entrepreneurship... broom it is!”",
        voiceName: "Zephyr",
        style: "Resigned comic submission",
      },
    ],
    funnyFact: "Golu swept the floor so vigorously that he classified it on LinkedIn as 'Executive Floor Management Specialist'.",
  },
  {
    id: 3,
    chapter: "Chapter 3",
    titleRoman: "Golu Ka Pehla Business & Budha Hone Ka Khauf",
    titleUrdu: "گولو کا پہلا بزنس اور بوڑھا ہونے کا خوف",
    titleEnglish: "First Business Pitch & The Fear of Growing Old",
    tagline: "“Bhai, itne time mein to main budha ho jaunga!” 😭🤣",
    image: "/src/assets/images/golu_daydreaming_crorepati_1791526026877.jpg",
    imageAlt: "Golu talking with his friend about learning skills and freelancing",
    bgGradient: "from-blue-500/20 via-cyan-500/10 to-transparent",
    accentColor: "border-blue-500 text-blue-500",
    fullNarrationRoman:
      "Golu ne faisla kiya ke woh online business karega. Usne apne dost se kaha: “Bhai, mujhe paisa kamana hai, koi idea de!” Dost bola: “Koi skill seekh le, freelancing kar!” Golu: “Skill seekhne mein kitna time lagega?” Dost: “Teen se chhe mahine practice karni par sakti hai.” Golu: “Bhai, itne time mein to main budha ho jaunga!” 😭🤣",
    fullUrduScript: "گولو نے فیصلہ کیا کہ وہ آن لائن بزنس کرے گا۔ اس نے اپنے دوست سے کہا: «بھائی، مجھے پیسہ کمانا ہے، کوئی آئیڈیا دے!» دوست بولا: «کوئی سکل سیکھ لے، فری لانسنگ کر!» گولو: «سکل سیکھنے میں کتنا ٹائم لگے گا؟» دوست: «تین سے چھ مہینے پریکٹس کرنی پڑ سکتی ہے۔» گولو: «بھائی، اتنے ٹائم میں تو میں بوڑھا ہو جاؤں گا!»",
    fullNarrationUrdu:
      "گولو نے فیصلہ کیا کہ وہ آن لائن بزنس کرے گا۔ اس نے اپنے دوست سے کہا: «بھائی، مجھے پیسہ کمانا ہے، کوئی آئیڈیا دے!» دوست بولا: «کوئی سکل سیکھ لے، فری لانسنگ کر!» گولو: «سکل سیکھنے میں کتنا ٹائم لگے گا؟» دوست: «تین سے چھ مہینے پریکٹس کرنی پڑ سکتی ہے۔» گولو: «بھائی، اتنے ٹائم میں تو میں بوڑھا ہو جاؤں گا!» 😭🤣",
    fullNarrationEnglish:
      "Golu decided he would conquer the online business world. He asked his best friend: 'Bro, I want to make tons of money, give me an idea!' Friend said: 'Learn a real high-income skill, do freelancing!' Golu asked: 'How long to learn the skill?' Friend: 'Might take 3 to 6 months of practice.' Golu wailed: 'Bro! By that time I will be an old grandfather!' 😭🤣",
    ttsScript:
      "Golu ne faisla kiya ke woh online business karega! Usne apne dost se kaha: 'Bhai, mujhe paisa kamana hai, koi idea de!' Dost bola: 'Koi skill seekh le, freelancing kar!' Golu bola: 'Skill seekhne mein kitna time lagega?' Dost bola: 'Teen se chhe mahine!' Golu roya: <gasp> 'Bhai, itne time mein to main budha ho jaunga!'",
    soundEffect: "Sad Violin & Dramatic Sigh 🎻",
    dialogues: [
      {
        speaker: "Golu",
        textRoman: "“Bhai, mujhe instant paisa chahiye! Koi shortcut button hai internet par?”",
        textUrdu: "«بھائی، مجھے انسٹنٹ پیسہ چاہیے! کوئی شارٹ کٹ بٹن ہے انٹرنیٹ پر؟»",
        textEnglish: "“Bro, I need instant cash! Is there a shortcut button on the internet?”",
        voiceName: "Zephyr",
        style: "Impatient lazy hustler",
      },
      {
        speaker: "Dost",
        textRoman: "“Bhai shortcut nahi, graphic designing ya web development seekh le! 3 se 6 mahine lagenge.”",
        textUrdu: "«بھائی شارٹ کٹ نہیں، گرافک ڈیزائننگ یا ویب ڈویلپمنٹ سیکھ لے! ۳ سے ۶ مہینے لگیں گے۔»",
        textEnglish: "“No shortcuts bro, learn graphic design or web development! Takes about 3 to 6 months.”",
        voiceName: "Fenrir",
        style: "Realistic sensible friend",
      },
      {
        speaker: "Golu",
        textRoman: "“Chhe mahine?! Bhai itne time mein to mere baal safaid ho jayenge! Budha ho kar ameer hone ka kya faida?” 😭",
        textUrdu: "«چھ مہینے؟! بھائی اتنے ٹائم میں تو میرے بال سفید ہو جائیں گے! بوڑھا ہو کر امیر ہونے کا کیا فائدہ؟»",
        textEnglish: "“Six months?! My hair will turn grey! What's the point of becoming rich as an old man?”",
        voiceName: "Zephyr",
        style: "Over-dramatic panic",
      },
    ],
    funnyFact: "Golu thought 6 months was a century, but spent 8 months arguing with strangers in YouTube comment sections.",
  },
  {
    id: 4,
    chapter: "Chapter 4",
    titleRoman: "Poster Hai Ya Bijli Ka Bill? (The First Roast)",
    titleUrdu: "پوسٹر ہے یا بجلی کا بل؟ (پہلا کلائنٹ روسٹ)",
    titleEnglish: "Is This a Poster or an Electricity Bill? (Client Roast)",
    tagline: "“Bhai, yeh poster hai ya bijli ka bill?” 😂⚡",
    image: "/src/assets/images/golu_graphic_design_roast_1791526058667.jpg",
    imageAlt: "Golu showing chaotic design to client who thinks it looks like a power bill",
    bgGradient: "from-purple-500/20 via-indigo-500/10 to-transparent",
    accentColor: "border-purple-500 text-purple-500",
    fullNarrationRoman:
      "Phir bhi Golu ne graphic designing seekhna shuru kar di. Pehle din usne aik poster banaya. Rainbow colors, 20 mukhtalif fonts aur ajeeb layout! Client ne dekha aur sar pakar kar kaha: “Bhai, yeh poster hai ya bijli ka bill?” 😂 Golu ka dil toota, lekin usne practice nahi chhori. Usne client ke roast ko fuel banaya!",
    fullUrduScript: "پھر بھی گولو نے گرافک ڈیزائننگ سیکھنا شروع کر دی۔ پہلے دن اس نے ایک پوسٹر بنایا۔ کلائنٹ نے دیکھا اور کہا: «بھائی، یہ پوسٹر ہے یا بجلی کا بل؟» گولو کا دل ٹوٹا، لیکن اس نے پریکٹس نہیں چھوڑی۔",
    fullNarrationUrdu:
      "پھر بھی گولو نے گرافک ڈیزائننگ سیکھنا شروع کر دی۔ پہلے دن اس نے ایک پوسٹر بنایا۔ کلائنٹ نے دیکھا اور کہا: «بھائی، یہ پوسٹر ہے یا بجلی کا بل؟» 😂 گولو کا دل ٹوٹا، لیکن اس نے پریکٹس نہیں چھوڑی۔",
    fullNarrationEnglish:
      "Yet, Golu swallowed his pride and started learning graphic design. On his very first attempt, he designed a promotional poster. The client took one bewildered look, scratched his head, and asked: 'Bro, is this a poster or an electricity utility bill?' 😂 Golu's heart shattered into pieces, but he refused to quit. He kept practicing night and day!",
    ttsScript:
      "Phir bhi Golu ne graphic designing seekhna shuru kar di. Pehle din usne aik poster banaya. Client ne dekha aur sar pakar kar kaha: <laugh> 'Bhai, yeh poster hai ya bijli ka bill?' Golu ka dil toota, magar usne practice nahi chhori!",
    soundEffect: "Record Scratch & Shocked Gasp ⚡",
    dialogues: [
      {
        speaker: "Golu",
        textRoman: "“Sir, yeh dekhein mera masterpiece! Colors dekhein, fonts dekhein, aesthetic check karein!”",
        textUrdu: "«سر، یہ دیکھیں میرا ماسٹر پیس! کلرز دیکھیں، فونٹس دیکھیں، ایستھیٹک چیک کریں!»",
        textEnglish: "“Sir, behold my masterpiece! Look at the vibrant rainbow colors, 18 fonts, pure aesthetic!”",
        voiceName: "Zephyr",
        style: "Overly confident newbie designer",
      },
      {
        speaker: "Client",
        textRoman: "“Bhai, yeh poster hai ya bijli ka bill? Mujhe to meter reading aur fine ki date dhoondni par rahi hai!” 💀",
        textUrdu: "«بھائی، یہ پوسٹر ہے یا بجلی کا بل؟ مجھے تو میٹر ریڈنگ اور فائن کی تاریخ ڈھونڈنی پڑ رہی ہے!»",
        textEnglish: "“Brother, is this an advertising poster or an electric utility bill? I am searching for the meter units and overdue fine!”",
        voiceName: "Charon",
        style: "Deadpan shocked client with dry humor",
      },
      {
        speaker: "Golu",
        textRoman: "“Koi baat nahi! Agli baar aisi design banaunga ke log bijli ka bill bhool jayenge!”",
        textUrdu: "«کوئی بات نہیں! اگلی بار ایسا ڈیزائن بناؤں گا کہ لوگ بجلی کا بل بھول جائیں گے!»",
        textEnglish: "“No worries! Next time my design will be so crisp, you'll forget electricity bills ever existed!”",
        voiceName: "Zephyr",
        style: "Determined comeback spirit",
      },
    ],
    funnyFact: "The client actually showed Golu's poster to his wife thinking it was the overdue water bill for July.",
  },
  {
    id: 5,
    chapter: "Chapter 5",
    titleRoman: "Pehli Kamai: ₹5,000 & Ammi's Epic Plot Twist",
    titleUrdu: "پہلی کمائی: ۵۰۰۰ روپے اور امی کا زبردست موڑ",
    titleEnglish: "First ₹5,000 Income & Mom's Epic Plot Twist",
    tagline: "“Mashallah! Ab bijli ka bill bhar de!” 💀💸",
    image: "/src/assets/images/golu_five_thousand_victory_1791526078748.jpg",
    imageAlt: "Golu celebrating his 5,000 rupees earning while Ammi hands him the electricity bill",
    bgGradient: "from-emerald-500/20 via-teal-500/10 to-transparent",
    accentColor: "border-emerald-500 text-emerald-500",
    fullNarrationRoman:
      "Kuch mahino baad uska kaam behtar ho gaya. Usay pehla client mila aur usne 5,000 rupay kamaye! Golu khushi se bhaagta hua Ammi ke paas gaya: “Ammi! Main paisay kama kar aa gaya!” Ammi boli: “Mashallah! Ab bijli ka bill bhar de.” Golu: “AMMI! Main abhi billionaire nahi bana!” 💀😂",
    fullUrduScript: "کچھ مہینوں بعد اس کا کام بہتر ہو گیا۔ اسے پہلا کلائنٹ ملا اور اس نے ۵۰۰۰ روپے کمائے! گولو خوشی سے بھاگتا ہوا امی کے پاس گیا: «امی! میں پیسے کما کر آ گیا!» امی بولی: «ماشاءاللہ! اب بجلی کا بل بھر دے۔» گولو: «امی! میں ابھی بلینیئر نہیں بنا!»",
    fullNarrationUrdu:
      "کچھ مہینوں بعد اس کا کام بہتر ہو گیا۔ اسے پہلا کلائنٹ ملا اور اس نے ۵۰۰۰ روپے کمائے! گولو خوشی سے بھاگتا ہوا امی کے پاس گیا: «امی! میں پیسے کما کر آ گیا!» امی بولی: «ماشاءاللہ! اب بجلی کا بل بھر دے۔» گولو: «امی! میں ابھی بلینیئر نہیں بنا!» 💀😂",
    fullNarrationEnglish:
      "A few months of relentless dedication paid off. His designs grew sharp, he landed his first legitimate client, and earned 5,000 rupees! Ecstatic, Golu raced into the house waving the currency notes: 'Mom! Look, your boy has earned real cash!' Mom smiled proudly: 'MashaAllah! Now go pay the electricity bill.' Golu cried: 'MOM! I haven't become a billionaire yet!' 💀😂",
    ttsScript:
      "Kuch mahino baad uska kaam behtar ho gaya. Usay pehla client mila aur usne 5,000 rupay kamaye! Golu khushi se bhaagta hua Ammi ke paas gaya: 'Ammi! Main paisay kama kar aa gaya!' Ammi boli: 'Mashallah beta! Ab bijli ka bill bhar de.' Golu chillaya: <gasp> 'AMMI! Main abhi billionaire nahi bana!' <laugh>",
    soundEffect: "Money Cash Register Ka-Ching & Confetti 💰🎉",
    dialogues: [
      {
        speaker: "Golu",
        textRoman: "“Ammi! Dekh tera beta kamao ban gaya! Paanch hazaar rupay! Main ab official businessman hoon!” 🎉",
        textUrdu: "«امی! دیکھ تیرا بیٹا کماؤ بن گیا! پانچ ہزار روپے! میں اب آفیشل بزنس مین ہوں!»",
        textEnglish: "“Mom! Look, your boy is officially a breadwinner! 5,000 rupees! I am a certified business tycoon!”",
        voiceName: "Zephyr",
        style: "Pure jubilation and pride",
      },
      {
        speaker: "Ammi",
        textRoman: "“Mashallah beta! Kitna pyaara lag raha hai. Aik kaam kar, pehle yeh chaar hazaar aath sau ka bijli ka bill bhar kar aa!” 📄⚡",
        textUrdu: "«ماشاءاللہ بیٹا! کتنا پیارا لگ رہا ہے۔ ایک کام کر، پہلے یہ چار ہزار آٹھ سو کا بجلی کا بل بھر کر آ!»",
        textEnglish: "“MashaAllah son! You look splendid. Now do one thing, go pay this 4,850 rupee electricity bill first!”",
        voiceName: "Kore",
        style: "Sweet loving mom turning ruthless accountant",
      },
      {
        speaker: "Golu",
        textRoman: "“AMMI! Main abhi billionaire nahi bana! Bacha kya mere paas? Sirf do sau rupay?!” 😭",
        textUrdu: "«امی! میں ابھی بلینیئر نہیں بنا! بچا کیا میرے پاس؟ صرف دو سو روپے؟!»",
        textEnglish: "“MOM! I'm not Elon Musk yet! What do I have left? Just two hundred rupees?!”",
        voiceName: "Zephyr",
        style: "Comedic despair and panic",
      },
    ],
    funnyFact: "The electricity bill was ₹4,850. Golu saved exactly ₹150 with which he bought two samosas to celebrate his billionaire journey.",
  },
  {
    id: 6,
    chapter: "Chapter 6",
    titleRoman: "Asli Zindagi Ke 5 Sabaq & Golu's Golden Punchline",
    titleUrdu: "اصلی زندگی کے ۵ سبق اور گولو کا گولڈن ڈائیلاگ",
    titleEnglish: "5 Life Lessons & Golu's Iconic Dialogue",
    tagline: "“ATM machine bhi bina card ke paisa nahi deti!” 🏧🔥",
    image: "/src/assets/images/golu_five_thousand_victory_1791526078748.jpg",
    imageAlt: "Golu sharing life lessons with high energy and confidence",
    bgGradient: "from-amber-500/20 via-yellow-500/10 to-transparent",
    accentColor: "border-amber-500 text-amber-500",
    fullNarrationRoman:
      "Golu ko aakhir samajh aa gaya: Sirf motivational videos dekhne se paisa nahi aata. Skill seekho, phir apni service becho. Client mana kare to seekho, ro kar Wi-Fi band mat karo. Kamai ho to sab kharch mat karo. Roz kaam karo, chahe shuru mein result chhota ho. Aur Golu ka aakhri dialogue: “Bhai, ameer banna hai to kaam karna parega… kyun ke ATM machine bhi bina card ke paisa nahi deti, aur Ammi bina kaam ke pocket money nahi detin!” Moral: Khuwab billionaire ke dekho, lekin kaam Monday se nahi — AAJ se shuru karo! 🔥",
    fullUrduScript: "گولو کو آخر سمجھ آ گیا: صرف موٹیویشنل ویڈیوز دیکھنے سے پیسہ نہیں آتا۔ سکل سیکھو، پھر اپنی سروس بیچو۔ کلائنٹ منع کرے تو سیکھو، رو کر وائی فائی بند مت کرو۔ کمائی ہو تو سب خرچ مت کرو۔ روز کام کرو، چاہے شروع میں رزلٹ چھوٹا ہو۔ اور گولو کا آخری ڈائیلاگ: بھائی، امیر بننا ہے تو کام کرنا پڑے گا... کیونکہ اے ٹی ایم مشین بھی بنا کارڈ کے پیسہ نہیں دیتی، اور امی بنا کام کے پاکٹ منی نہیں دیتیں!",
    fullNarrationUrdu:
      "گولو کو آخر سمجھ آ گیا: صرف موٹیویشنل ویڈیوز دیکھنے سے پیسہ نہیں آتا۔ سکل سیکھو، پھر اپنی سروس بیچو۔ کلائنٹ منع کرے تو سیکھو، رو کر وائی فائی بند مت کرو۔ کمائی ہو تو سب خرچ مت کرو۔ روز کام کرو، چاہے شروع میں رزلٹ چھوٹا ہو۔ اور گولو کا آخری ڈائیلاگ: «بھائی، امیر بننا ہے تو کام کرنا پڑے گا… کیونکہ اے ٹی ایم مشین بھی بنا کارڈ کے پیسہ نہیں دیتی، اور امی بنا کام کے پاکٹ منی نہیں دیتیں!» 🤣🤣🤣 اخلاق: خواب بلینیئر کے دیکھو، لیکن کام پیر سے نہیں — آج سے شروع کرو! 🔥",
    fullNarrationEnglish:
      "Golu finally understood the grand formula of life: 1. Watching motivational videos won't make you rich. 2. Learn a real skill, then sell your service. 3. If a client rejects you, learn and iterate; don't cry and turn off the Wi-Fi. 4. When you earn, don't blow it all (mom has electricity bills waiting!). 5. Work every single day, even if initial results are humble. And Golu's legendary closing words: 'Bro, if you want to become wealthy, you have to work... because even an ATM won't dispense money without a card, and Ammi never gives pocket money without chores!' Moral: Dream like a billionaire, but start grinding not from next Monday — but TODAY!",
    ttsScript:
      "Golu ko aakhir samajh aa gaya: Sirf motivational videos dekhne se paisa nahi aata! Skill seekho, service becho! Client mana kare to seekho, ro kar Wi-Fi band mat karo! Aur Golu ka golden dialogue: 'Bhai, ameer banna hai to kaam karna parega... kyun ke ATM machine bhi bina card ke paisa nahi deti, aur Ammi bina kaam ke pocket money nahi detin!' <laugh> Khuwab billionaire ke dekho, lekin kaam AAJ se shuru karo!",
    soundEffect: "Triumphant Fanfare & Applause 🎺👏",
    dialogues: [
      {
        speaker: "Golu",
        textRoman: "“Bhai, ameer banna hai to kaam karna parega… kyun ke ATM machine bhi bina card ke paisa nahi deti, aur Ammi bina kaam ke pocket money nahi detin!” 🤣🤣🤣",
        textUrdu: "«بھائی، امیر بننا ہے تو کام کرنا پڑے گا… کیونکہ اے ٹی ایم مشین بھی بنا کارڈ کے پیسہ نہیں دیتی، اور امی بنا کام کے پاکٹ منی نہیں دیتیں!»",
        textEnglish: "“Bro, if you want to get rich you gotta work... because even an ATM doesn't give cash without a card, and Mom never gives pocket money without doing chores!”",
        voiceName: "Zephyr",
        style: "Philosophical comedic triumph",
      },
    ],
    funnyFact: "Golu now runs a design agency called 'Bijli Ka Bill Creatives' and makes ₹250,000 every month!",
  },
];

export const FIVE_GOLDEN_RULES = [
  {
    icon: "😂",
    ruleRoman: "Sirf motivational videos dekhne se paisa nahi aata",
    ruleUrdu: "صرف موٹیویشنل ویڈیوز دیکھنے سے پیسہ نہیں آتا",
    ruleEnglish: "Just watching motivational hype videos won't put food or cash on the table",
    explanation: "YouTube algorithms make money from your views; you make money by creating value!",
  },
  {
    icon: "💻",
    ruleRoman: "Skill seekho, phir apni service becho",
    ruleUrdu: "سکل سیکھو، پھر اپنی سروس بیچو",
    ruleEnglish: "Master a real high-value skill first, then market your services",
    explanation: "Nobody buys empty confidence. Build competence, build a portfolio.",
  },
  {
    icon: "💪",
    ruleRoman: "Client mana kare to seekho, ro kar Wi-Fi band mat karo",
    ruleUrdu: "کلائنٹ منع کرے تو سیکھو، رو کر وائی فائی بند مت کرو",
    ruleEnglish: "If a client roasts or rejects you, iterate; don't rage-quit your internet",
    explanation: "Every roast is a free design critique. Golu turned 'Bijli ka Bill' into ₹5,000!",
  },
  {
    icon: "💰",
    ruleRoman: "Kamai ho to sab kharch mat karo (Bijli ka bill yaad rakho)",
    ruleUrdu: "کمائی ہو تو سب خرچ مت کرو (بجلی کا بل یاد رکھو)",
    ruleEnglish: "Don't splurge all earnings immediately; household bills come first",
    explanation: "Smart cash flow management keeps your electricity on and your Ammi happy.",
  },
  {
    icon: "🚀",
    ruleRoman: "Roz kaam karo, chahe shuru mein result chhota ho",
    ruleUrdu: "روز کام کرو، چاہے شروع میں رزلٹ چھوٹا ہو",
    ruleEnglish: "Execute every single day, even when the initial harvest is modest",
    explanation: "Small consistent daily iterations compound into unstoppable momentum.",
  },
];

export const FUNNY_SOUND_EFFECTS = [
  {
    id: "jhaaru",
    name: "Ammi's Jhaaru Swoosh",
    emoji: "🧹",
    desc: "Sweep floor before billionaire talks",
    toneFreq: 220,
    type: "noise",
  },
  {
    id: "bruh",
    name: "Bruh / Emotional Damage",
    emoji: "💀",
    desc: "When client calls your poster a power bill",
    toneFreq: 140,
    type: "sawtooth",
  },
  {
    id: "kaching",
    name: "Ka-Ching! ₹5,000",
    emoji: "💸",
    desc: "The sweet sound of first client payment",
    toneFreq: 980,
    type: "sine",
  },
  {
    id: "bill",
    name: "Bijli Ka Bill Shock",
    emoji: "⚡",
    desc: "When Ammi takes ₹4,850 out of ₹5,000",
    toneFreq: 440,
    type: "triangle",
  },
  {
    id: "dhoom",
    name: "Dramatic Soap Opera Sting",
    emoji: "😱",
    desc: "Dhoom Tana Nana moment with Ammi",
    toneFreq: 180,
    type: "square",
  },
  {
    id: "cheer",
    name: "Victory Fanfare",
    emoji: "🎉",
    desc: "Celebrate Golu's first legitimate success",
    toneFreq: 523,
    type: "sine",
  },
];
