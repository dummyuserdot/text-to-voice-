import express, { Request, Response } from "express";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json({ limit: "10mb" }));

// Server-side Gemini client with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

/**
 * Text-to-Speech Endpoint using gemini-3.8-flash-tts
 * Supports unary WAV generation with custom expressive voices
 */
app.post("/api/tts", async (req: Request, res: Response) => {
  try {
    const { text, voiceName = "Puck", style, speaker, multiSpeaker } = req.body;

    if (!text || typeof text !== "string") {
      res.status(400).json({ error: "Text is required for TTS generation." });
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      res.status(503).json({
        error: "GEMINI_API_KEY is not configured.",
        fallback: true,
      });
      return;
    }

    if (multiSpeaker && Array.isArray(multiSpeaker.speakers) && multiSpeaker.speakers.length === 2) {
      // Dual-speaker dialogue mode
      const [spk1, spk2] = multiSpeaker.speakers;
      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash-tts",
        contents: [
          {
            role: "user",
            parts: multiSpeaker.lines.map((line: { speaker: string; text: string; style?: string }) => ({
              text: `${line.speaker}: ${line.text}`,
              speechMetadata: {
                speaker: line.speaker,
                style: line.style || "Lively comedic conversational acting with rich vocal expressions",
              },
            })),
          },
        ],
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            multiSpeakerVoiceConfig: {
              speakerVoiceConfigs: [
                {
                  speaker: spk1.name,
                  voiceConfig: { prebuiltVoiceConfig: { voiceName: spk1.voiceName || "Puck" } },
                },
                {
                  speaker: spk2.name,
                  voiceConfig: { prebuiltVoiceConfig: { voiceName: spk2.voiceName || "Kore" } },
                },
              ],
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) {
        throw new Error("No audio payload returned from Gemini TTS model.");
      }

      res.json({
        audio: base64Audio,
        mimeType: "audio/wav",
        model: "gemini-3.8-flash-tts",
      });
      return;
    }

    // Single-speaker TTS mode
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash-tts",
      contents: [
        {
          role: "user",
          parts: [
            {
              text: text,
              speechMetadata: {
                speaker: speaker || "Narrator",
                style: style || "Dramatic, comedic, enthusiastic storyteller with natural pacing, laughter, and Urdu/Hindi accent",
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName || "Puck" },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    if (!base64Audio) {
      throw new Error("No audio payload received from Gemini TTS model.");
    }

    res.json({
      audio: base64Audio,
      mimeType: "audio/wav",
      model: "gemini-3.8-flash-tts",
    });
  } catch (error: any) {
    console.error("Gemini TTS Error:", error);
    res.status(500).json({
      error: error?.message || "Failed to generate speech with gemini-3.8-flash-tts",
      fallback: true,
    });
  }
});

/**
 * Ask Golu or Ammi advice endpoint using gemini-3.8-flash
 */
app.post("/api/ask-character", async (req: Request, res: Response) => {
  try {
    const { character, question } = req.body;

    if (!question) {
      res.status(400).json({ error: "Question is required." });
      return;
    }

    const personaInstructions =
      character === "ammi"
        ? `You are Ammi, the hilarious, sharp-tongued yet deeply loving desi mother of Golu.
You believe in hard work, clean rooms, paying electricity bills on time, and waving the traditional jhaaru (broom) when Golu gives lazy billionaire excuses.
Respond in witty Roman Urdu (with a dash of Hindi/English punchlines). Keep it punchy, funny, between 2 to 4 sentences, and end with a reality-check advice!`
        : `You are Golu, the legendary boy who used to search "1 din mein crore pati kaise banein" on YouTube at 12 PM, survived Ammi's broomstick therapy, learned freelancing after getting roasted for making a poster that looked like a "bijli ka bill", and made ₹5,000!
You give hilarious yet surprisingly genuine advice to aspiring hustlers.
Speak in enthusiastic, humorous Roman Urdu (with emojis and funny desi slang). Keep it between 2 to 4 sentences, and remind them that even ATMs need a card to give cash!`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: question,
      config: {
        systemInstruction: personaInstructions,
        temperature: 0.9,
      },
    });

    res.json({
      reply: response.text || "Bhai internet chala gaya, lagta hai Ammi ne router band kar diya! 😂",
      character,
    });
  } catch (error: any) {
    console.error("Character Q&A Error:", error);
    res.status(500).json({
      error: error?.message || "Could not get character advice.",
      reply: "Ammi ne jhaaru dikha diya, dialogue ruk gaya! (API limit or error)",
    });
  }
});

/**
 * Roast Golu's Poster Generator endpoint
 */
app.post("/api/roast-poster", async (req: Request, res: Response) => {
  try {
    const { title, colors, font, elements } = req.body;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `Critique this amateur poster designed by Golu:
Title: "${title || "Mega Discount Sale"}"
Colors: ${colors || "Neon Yellow, Electric Pink, Muddy Brown"}
Font: ${font || "Comic Sans Extra Bold"}
Elements: ${elements || "Clipart stars, 15 discount badges, floating pizza"}

Act as the perplexed Client who thinks it looks like an electric utility bill (bijli ka bill) or a railway timetable.
Give a short hilarious roast in Roman Urdu/Hindi (2 sentences), plus an absurd "Utility Bill Likeness Score" out of 100%. Return valid JSON: { "roast": "...", "billScore": 95, "ammiReaction": "..." }`,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (error: any) {
    console.error("Roast Poster Error:", error);
    res.json({
      roast: "Bhai yeh poster kam aur WAPDA ka bijli ka bill zyada lag raha hai! Pehle meter number dhoondoon ya text parhoon? 😂",
      billScore: 98,
      ammiReaction: "Ammi: Iss bill ko dekh kar to sach mein bijli ka jhatka lag gaya!",
    });
  }
});

// Vite Middleware for Development / Static serving for Production
async function setupServer() {
  const isProd = process.env.NODE_ENV === "production";

  if (!isProd) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, "dist")));
    app.get("*", (_req, res) => {
      res.sendFile(path.resolve(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

setupServer();
